import 'package:firebase_auth/firebase_auth.dart';

class AuthService {

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<UserCredential> login({
    required String email,
    required String password,
  }) async {

    return await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );

  }

  Future<void> logout() async {

    await _auth.signOut();

  }

  User? get currentUser {

    return _auth.currentUser;

  }

}